import React, {useState} from 'react';
import {BrowserRouter,Route,Routes} from 'react-router-dom';
import './App.css'

//component imports
import Dashboard from "./components/Dashboard"
import CreateStoreForm from './components/createStoreForm';
import ShowOneStore from './components/ShowOneStore';
import UpdateForm from './components/UpdateForm';

function App() {
  const [allStores, setAllStores]=useState([])
  const removeFromDom=(storeId)=>{
    setAllStores(allStores.filter(store=>store._id != storeId));
  }


  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Dashboard allStores={allStores} setAllStores={setAllStores}  removeFromDom={removeFromDom}/>} path="/"/>
        <Route element={<CreateStoreForm allStores={allStores} setAllStores={setAllStores}/>} path="/store/add"/>
        <Route element={<ShowOneStore/>} path="/store/:id"/>
        <Route element={<UpdateForm/>} path="store/edit/:id"/>
      </Routes>
    </BrowserRouter>
  )
}

export default App
