import React,{useState} from "react";
import { useNavigate,Link } from "react-router-dom";
import axios from "axios";



const CreateStoreForm=(allStores,setAllStores)=>{

    //State
    const [name, setName]=useState("");
    const [storeNumber,setStoreNumber]=useState("");
    const [isOpen,setIsOpen]=useState(false);
    const navigate=useNavigate();
    const [errors,setErrors]=useState([]);


    //handlers
    const createFormHandler=(e)=>{
        e.preventDefault();
        axios.post("http://localhost:8000/api/store",{name,storeNumber,isOpen})
            .then(res=>{
                console.log(res)
                console.log(res.data,"xxxxxxxxxxxxxxxxx")
                navigate(`/store/`+res.data._id)
            })//end then
            .catch(err=>{
                console.log(err.response.data)
                const errArray=[]
                for (const key of Object.keys(err.response.data.errors)){
                    errArray.push(err.response.data.errors[key].message)
                }
                setErrors(errArray);
            })//end catch
    }//end form handler

    const returnHomeHandler=()=>{
        navigate("/")
    }//end home handler


    return(
        <>
            <div>
                <h1>Store Finder</h1>
                <button onClick={returnHomeHandler}> onClickHomePage</button>
            </div>
            <h3>Fill Out Form To Add New Store!</h3>
            <form onSubmit={createFormHandler}>
            <div style={{color:"red"}}>
                {
                    errors.map((err,idx)=>{
                        return(
                            <p key={idx}>{err}</p>
                        )//end map return
                    })//end map
                }
            </div>
                <div>
                    <label>Store Name:</label>
                    <input type="text" value={name} onChange={e=>setName(e.target.value)}/>
                </div>
                <div>
                    <label>Store Number:</label>
                    <input type="number" value={storeNumber} onChange={e=>setStoreNumber(e.target.value)}/>
                </div>
                <div>
                    <label>Open?</label>
                    <input type="checkbox" checked={isOpen}  onChange={e=>setIsOpen(e.target.checked)}/> 
                </div>  
                <input type="submit" value="Add New Store" />
            </form>
        </>
    )//end return



}//end create store form
export default CreateStoreForm;