import React, { useEffect } from "react";
import { useNavigate,Link} from "react-router-dom";
import axios from 'axios';


const Dashboard=({allStores, setAllStores,removeFromDom})=>{

    const navigate=useNavigate();

    useEffect(()=>{
        axios.get("http://localhost:8000/api/allStores")
            .then((res)=>{
                console.log(res.data);
                setAllStores(res.data);
            })
            .catch(err=>console.log(err));
    },[]);//end useEffect

    //handlers
    const addNewButtonHandler=(e)=>{
        navigate("/store/add")
    }//end add new button handler

    const deleteHandler=(storeId)=>{
        axios.delete("http://localhost:8000/api/store/" + storeId)
            .then(res=>{
                removeFromDom(storeId)
            })//end then
            .catch(err=>console.log(err))
    }//end delete handler

    return(
        <>
            <div>
                <h1>Store Finder</h1>
                <p>Find Stores in your area!</p>
            </div>
            <hr/>
            <table>
                <thead>
                <tr>
                        <th>Store</th>
                        <th>Store Number</th>
                        <th>Open</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        allStores.map((store,index)=>{
                            return(
                                <tr key={index}>
                                    <td><Link to={`/store/${store._id}`}>{store.name}</Link></td>
                                    <td>{store.storeNumber}</td>
                                    {store.isOpen?<td>True</td>:<td>False</td>}
                                    <td><button onClick={(e)=>deleteHandler(store._id)}>Delete</button></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <button onClick={addNewButtonHandler}>Add New Store</button>
        </>
    )

}//end Dashboard component
export default Dashboard;