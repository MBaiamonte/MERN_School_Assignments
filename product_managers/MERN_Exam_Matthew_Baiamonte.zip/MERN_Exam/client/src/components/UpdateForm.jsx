import React,{useEffect, useState} from "react";
import { useNavigate,useParams } from "react-router-dom";
import axios from "axios";

const UpdateForm=(props)=>{
    const [name,setName]=useState();
    const [storeNumber,setStoreNumber]=useState()
    const [isOpen,setIsOpen]=useState();
    const {id}=useParams();
    const navigate=useNavigate();

    useEffect(()=>{
        axios.get("http://localhost:8000/api/store/"+ id)
        .then(res=>{
            setName(res.data.name)
            setStoreNumber(res.data.storeNumber)
            setIsOpen(res.data.isOpen)
        })//end then
        .catch(err=>console.log(err))
    },[])//end useEffect

    const updateStoreHandler=(e)=>{
        e.preventDefault();
        axios.patch("http://localhost:8000/api/store/"+id, {name,storeNumber,isOpen})
        .then(res=>{
            console.log(res.data)
            navigate("/store/"+ id)
        })//end then
        .catch(err=>console.log(err.response.data.errors))
    }
    const returnHomeHandler=()=>{
        navigate("/")
    }//end home handler


    return(
        <>
            <div>
                <h1>Store Finder</h1>
                <button onClick={returnHomeHandler}> onClickHomePage</button>
            </div>
            <h3>Update Store Information!</h3>
            <form onSubmit={updateStoreHandler}>
                <div>
                    <label>Store Name:</label>
                    <input type="text" value={name} onChange={e=>setName(e.target.value)}/>
                </div>
                <div>
                    <label>Store Number:</label>
                    <input type="number" value={storeNumber} onChange={e=>setStoreNumber(e.target.value)}/>
                </div>
                <div>
                    <label>Open?</label>
                    <input type="checkbox" checked={isOpen}  onChange={e=>setIsOpen(e.target.checked)}/> 
                </div>  
                <input type="submit" value="Update Store" />
            </form>
        
        </>
    )
}
export default UpdateForm;