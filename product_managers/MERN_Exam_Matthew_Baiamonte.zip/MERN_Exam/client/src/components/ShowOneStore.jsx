import React,{useEffect, useState} from "react";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";

const ShowOneStore=(props)=>{
    const navigate=useNavigate();
    const [store, setStore]=useState({})
    const {id}=useParams();

    useEffect(()=>{
        axios.get("http://localhost:8000/api/store/"+ id)
        .then(res=>{
            console.log(res.data)
            setStore(res.data)
        })//end then
        .catch(err=>console.log(err))
    },[])//end useEffect

    const returnHomeHandler=()=>{
        navigate("/")
    }//end home handeler

    const editLinkHandler=()=>{
        navigate(`/store/edit/${id}`)
    }


return(
    <>
        <div>
            <h1>Store Finder</h1>
            <button onClick={returnHomeHandler}> onClickHomePage</button>
        </div>
        <hr/>
        <div>
            <p>Store Name: {store.name}</p>
            <p>Store Number: {store.storeNumber}</p>
            {
                store.isOpen?<p>{store.name} is Open</p>:<p>{store.name} is now Closed</p>
            } 
            <hr/>
            <button onClick={editLinkHandler}>Edit Store information</button>
        </div>
    </>
)

}
export default ShowOneStore;