const Store = require("../models/Store");

module.exports.findAllStores=(req,res)=>{
    Store.find()
    .then(allStores=>{
        res.json(allStores)
    })//end then
    .catch((err)=>{
        res.status.json({message: "Something went wrong with get all xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", error:err})
    }); //end catch
}//end get all

module.exports.findOneStore=(req,res)=>{
    Store.findById(req.params.id)
        .then(oneStore=>res.json(oneStore))
        .catch((err)=>{
            res.json({message: "Something went wrong with get one xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", error:err})
        }); //end catch
}//end get one

module.exports.createStore=(req,res)=>{
    Store.create(req.body)
        .then(newStore=>res.json(newStore))
        .catch((err)=>{
            res.status(400).json(err)
        }); //end catch
}//end create

module.exports.updateStore=(req,res)=>{
    Store.findOneAndUpdate(
        {_id:req.params.id},
        req.body,
        {new:true, runValidators:true}
        )
        .then(updatedStore=>{
            res.json(updatedStore)
        })//end then
        .catch((err)=>{
            res.json({message: "Something went wrong with update store xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", error:err})
        }); //end catch
}//end update

module.exports.deleteOneStore=(req,res)=>{
    Store.deleteOne({_id:req.params.id})
        .then(deleteConfirmation=>{res.json(deleteConfirmation)
    })//end then
    .catch((err)=>{
        res.json({message: "Something went wrong with delete one store xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", error:err})
    }); //end catch
}//end delete one