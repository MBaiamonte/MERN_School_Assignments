const Store = require("../controllers/store");

module.exports = app =>{
    app.get("/api/allStores",Store.findAllStores)
    app.post("/api/store",Store.createStore)
    app.get("/api/store/:id",Store.findOneStore)
    app.patch("/api/store/:id",Store.updateStore)
    app.delete("/api/store/:id",Store.deleteOneStore)

}//end store routes