const mongoose = require('mongoose');
const StoreSchema= new mongoose.Schema({
    name:{
        type: String,
        required: [true, "Store Name is required"],
        minlength: [3, "Store Name must be at least three character long"]
    },
    storeNumber:{
        type: Number,
        required: [true, "Store Number is required"],
        min: [1, "Store Number must be greater than zero"]
    },
    isOpen:{
        type: Boolean,
        required: [true, "Must State is Store is open or not"]
    }
}, {timestamps: true});

const Store = mongoose.model("Store", StoreSchema);
module.exports = Store;