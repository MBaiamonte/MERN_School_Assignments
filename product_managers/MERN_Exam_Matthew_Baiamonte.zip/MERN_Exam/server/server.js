const express = require('express');
const app = express();
const port = 8000;
const cors = require('cors')


require("../server/config/mongoose");
app.use(
    express.json(),
    express.urlencoded({extended:true}), 
    cors()
    );

require("./config/mongoose"); //require mongoose

const AllMyStoreRoutes = require("./routes/store");
AllMyStoreRoutes(app);

app.listen(port, ()=>console.log("app is up and running on port:" + port))
