import React,{ useState } from 'react'
import HookForm from './components/HookForm'
import './App.css'

function App() {
  return (
    <div className='App'>
      <HookForm/>
    </div>
  )
}

export default App
