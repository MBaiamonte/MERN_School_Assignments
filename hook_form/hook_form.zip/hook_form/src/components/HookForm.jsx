import React, {useState} from 'react';

const HookForm= (props)=>{
    const [firstName,setFirstName]= useState("");
    const [lastName,setLastName]= useState("");
    const [email,setEmail]= useState("");
    const [password,setPassword]= useState("");
    const [confirmPassword,setConfirmPassword]= useState("");

    const createUser=(event)=>{
        event.preventDefault();
        const newUser={firstName,lastName,email,password,confirmPassword};
        console.log("welcome", newUser)
    ///  ^^^^ not seeing this print?
    } 
return(
    <>
        <form onSubmit={createUser}>
            <label>First Name: </label>
            <input type='text' onChange={(event)=>setFirstName(event.target.value)}/>

            <label>Last Name: </label>
            <input type='text' onChange={(event)=>setLastName(event.target.value)}/>

            <label>Email: </label>
            <input type='text' onChange={(event)=>setEmail(event.target.value)}/>

            <label>Password: </label>
            <input type='password' onChange={(event)=>setPassword(event.target.value)}/>

            <label>Confirm Password: </label>
            <input type='password' onChange={(event)=>setConfirmPassword(event.target.value)}/>

            <input type="submit" value="Submit"/>
        </form>
        <div>
            <h3>Form Data(below)</h3>
            <p>First Name: {firstName}</p>
            <p>Last Name: {lastName}</p>
            <p>Email:{email} </p>
            <p>Password:{password} </p>
            <p>Confirm Password: {confirmPassword} </p>
        </div>
    
    </>
);

}
export default HookForm;