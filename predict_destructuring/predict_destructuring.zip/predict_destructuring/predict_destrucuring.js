function problem_1(){
  let prediction= "first prints tesla the second prints mercedes ";
  console.log(prediction)
}
problem_1()
//problem 2

function problem_2(){
  let prediction= 'error since name is not a global variable its in the scope of the employee. so calling it will result in an undefined error. instead it needs to be employee.name. second console.log wouldnt have a problem and would print elon';
  console.log(prediction)
}
problem_2()
//problem 3
function problem_3(){
  let prediction= "first itll print out 12345, then it will print undefined becuse the person object doesnt have password set/declaired in its scope so theres nothing to return. ";
  console.log(prediction)
}
problem_3()

//problem 4
function problem_4(){
  let prediction= "fist it will print false then true. its asking if 2=5 then if 2=2";
  console.log(prediction)
}
problem_4()

//problem 5
function problem_5(){
  let prediction= " fist is value, second is the array 1,5,1,8,3,3 third itll print 1 lastly itll print 5 ";
  console.log(prediction)
}
problem_5()

//problem 6