import React from 'react'
import Pokemon from './components/pokemon'
import './App.css'

function App() {
  return (
    <>
      <Pokemon/>
    </>
  )
}

export default App
